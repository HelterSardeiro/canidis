/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Factory;

import DAO.BanhoDAO;
import View.Index;
import java.sql.Connection;
import java.sql.SQLException;
//import javax.swing.JOptionPane;

/**
 *
 * @author ifgoiano
 */
public class TestaConexao {
    public static void main(String[] args) throws SQLException {
        Connection conn = new ConnectionFactory().getConnection();
        //JOptionPane.showMessageDialog(null,"Conexão ok!");
        conn.close();
        Index indext = new Index();
        indext.setVisible(true);
    }
}
