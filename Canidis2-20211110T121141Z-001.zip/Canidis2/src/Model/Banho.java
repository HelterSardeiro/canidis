/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author sarde
 */
public class Banho {
    private int id;
    private String cpf;
    private String nomet;
    private String nomec;
    private String raca;
    private String fone;
    private String cell;
    private String endereco;
    private int qtdb;
    private String tosa;
    private String hidrat;
    private String datan;
    private String dataup;
    private String datadown;
    private String porte;
    
    
    
    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNomet() {
        return nomet;
    }

    public void setNomet(String nomet) {
        this.nomet = nomet;
    }

    public String getNomec() {
        return nomec;
    }

    public void setNomec(String nomec) {
        this.nomec = nomec;
    }

    public String getFone() {
        return fone;
    }

    public void setFone(String fone) {
        this.fone = fone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getQtdb() {
        return qtdb;
    }

    public void setQtdb(int qtdb) {
        this.qtdb = qtdb;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTosa() {
        return tosa;
    }

    public void setTosa(String tosa) {
        this.tosa = tosa;
    }

    public String getHidrat() {
        return hidrat;
    }

    public void setHidrat(String hidrat) {
        this.hidrat = hidrat;
    }

    public String getDatan() {
        return datan;
    }

    public void setDatan(String datan) {
        this.datan = datan;
    }

    public String getDataup() {
        return dataup;
    }

    public void setDataup(String dataup) {
        this.dataup = dataup;
    }

    public String getCell() {
        return cell;
    }

    public void setCell(String cell) {
        this.cell = cell;
    }

    public String getDatadown() {
        return datadown;
    }

    public void setDatadown(String datadown) {
        this.datadown = datadown;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public String getPorte() {
        return porte;
    }

    public void setPorte(String porte) {
        this.porte = porte;
    }
    
    
}
