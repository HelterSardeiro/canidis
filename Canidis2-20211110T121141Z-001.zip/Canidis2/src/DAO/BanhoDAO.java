/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Factory.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Model.Banho;
import java.sql.Date;
import java.text.SimpleDateFormat;
/**
 *
 * @author sarde
 */

    
    
public class BanhoDAO {
    Connection con;
    public BanhoDAO(){
        con = ConnectionFactory.getConnection();
    }
    
    public void create(Banho b) { //Criar banho

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("INSERT INTO banho (nomet,nomec,cpf,endereco,qtdb,fone,datan,tosa,hidrat,cell,raca,porte)VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
            stmt.setString(1, b.getNomet());
            stmt.setString(2, b.getNomec());
            stmt.setString(3, b.getCpf());
            stmt.setString(4, b.getEndereco());
            stmt.setInt(5, b.getQtdb());
            stmt.setString(6,b.getFone());
            stmt.setString(7,b.getDatan());
            stmt.setString(8,b.getTosa());
            stmt.setString(9,b.getHidrat());
            stmt.setString(10, b.getCell());
            stmt.setString(11, b.getRaca());
            stmt.setString(12, b.getPorte());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
        } catch (SQLException ex) {
            System.out.println(ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    
     
    public List<Banho> read() {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Banho> banhos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT * FROM banho");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Banho banho = new Banho();

                banho.setId(rs.getInt("id"));
                banho.setNomet(rs.getString("nomet"));
                banho.setNomec(rs.getString("nomec"));
                banho.setRaca(rs.getString("raca"));
                banho.setCpf(rs.getString("cpf"));
                banho.setPorte(rs.getString("porte"));
                banho.setEndereco(rs.getString("endereco"));
                banho.setQtdb(rs.getInt("qtdb"));
                banho.setFone(rs.getString("fone"));
                banho.setCell(rs.getString("cell"));
                banho.setDatan(rs.getString("datan"));
                banho.setDataup(rs.getString("dataup"));
                banho.setTosa(rs.getString("tosa"));
                banho.setHidrat(rs.getString("hidrat"));
                banhos.add(banho);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BanhoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return banhos;

    }
    
    public List<Banho> readd() {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Banho> banhos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("select  b.nomet, b.nomec, d.data from banho as b inner join datadown as d on d.id_banho = b.id");
            rs = stmt.executeQuery();

            while (rs.next()) {

                Banho banho = new Banho();
                banho.setNomet(rs.getString("nomet"));
                banho.setNomec(rs.getString("nomec"));
                banho.setDatadown(rs.getString("data"));
                banhos.add(banho);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BanhoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return banhos;

    }
    
    public List<Banho> readForQtd(String desc) {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Banho> banhos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT qtdb FROM banho WHERE cpf = ? limit 1");
            stmt.setString(1, desc);
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Banho banho = new Banho();
                banho.setQtdb(rs.getInt("qtdb"));
                banhos.add(banho);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BanhoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return banhos;

    }
    public List<Banho> readForId(String desc) {

        PreparedStatement stmt = null;
        ResultSet rs = null;

        List<Banho> banhos = new ArrayList<>();

        try {
            stmt = con.prepareStatement("SELECT id FROM banho WHERE cpf = ? limit 1");
            stmt.setString(1, desc);
            
            rs = stmt.executeQuery();

            while (rs.next()) {

                Banho banho = new Banho();
                banho.setId(rs.getInt("id"));
                banhos.add(banho);
            }

        } catch (SQLException ex) {
            Logger.getLogger(BanhoDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }

        return banhos;

    }
    public void update(Banho b) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE banho set qtdb = ? where cpf = ?");
            stmt.setInt(1, b.getQtdb());
            stmt.setString(2, b.getCpf());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public void created(Banho b) {

        PreparedStatement stmt = null;

        try {
            //stmt = con.prepareStatement("INSERT INTO datadown(data,id_banho) value (?,(select id from banho where cpf = ?))");
            stmt = con.prepareStatement("INSERT INTO datadown(data,id_banho) value (?, ?)");
            Date data = new Date(System.currentTimeMillis());  
            SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
            stmt.setString(1, formatarDate.format(data));
            stmt.setInt(2, b.getId());
       
            stmt.executeUpdate();

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
            System.out.println(ex);
        } 

    }
    
    public void updatePlus(Banho b) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE banho set qtdb = ?, dataup = ? WHERE cpf = ?");
            Date data = new Date(System.currentTimeMillis());  
            SimpleDateFormat formatarDate = new SimpleDateFormat("dd/MM/yyyy");
            stmt.setInt(1, b.getQtdb());
            stmt.setString(2, formatarDate.format(data));
            stmt.setString(3, b.getCpf());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    public void updateSit(Banho b) {

        PreparedStatement stmt = null;

        try {
            stmt = con.prepareStatement("UPDATE banho set tosa = ?,hidrat = ?  WHERE id = ?");
            stmt.setString(1, b.getTosa());
            stmt.setString(2, b.getHidrat());
            stmt.setInt(3, b.getId());
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(null, "Atualizado com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar: " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt);
        }

    }
    
    
    
}
